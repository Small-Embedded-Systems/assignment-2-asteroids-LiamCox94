void controls(void);
extern bool joyStickUp;
extern bool joyStickRight;
extern bool joyStickLeft;
extern bool joyStickDown;
extern bool joyStickCenter;
