/* support double buffering */
void init_DBuffer(void);
void swap_DBuffer(void);
void draw(void);
void ship();
